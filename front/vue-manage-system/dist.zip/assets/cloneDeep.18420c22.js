import{b as o}from"./_baseClone.42b50180.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
