import{N as o}from"./index.ac7ed872.js";const e=i=>o?window.requestAnimationFrame(i):setTimeout(i,16),r=i=>o?window.cancelAnimationFrame(i):clearTimeout(i);export{r as c,e as r};
