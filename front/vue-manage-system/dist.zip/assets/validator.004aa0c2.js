import{aD as i}from"./index.ac7ed872.js";const n=o=>["",...i].includes(o);export{n as i};
